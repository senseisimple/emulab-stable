TipTunnel
copyright 2002 The Flux Group, University of Utah.

Utility for remote, secure console connections.

http://www.emulab.net/
testbed-ops@fast.cs.utah.edu

Archive includes openSSL runtime, 
which offers strong cryptography.
Export, import, and/or use of this software may be
illegal from/to/in some countries.  
Visit http://www.openssl.org/ for more information.

1. Download and unzip this archive into a folder.
   "C:\Program Files\tiptunnel" may be an appropriate
   folder for this.
   Keep the included dlls in the same folder as the
   included tiptunnel binary.

2. Use your browser to navigate to the Node Information page
   for a node belonging to your project. Click the
   "Connect to serial line" link; this will give you a
   "text/x-testbedacl" file. Your browser should ask how to 
   open these files; tell your browser to always
   use the "tiptunnel.exe" binary for them.

3. You can now use the "Connect to serial line" link in the 
   Node Information page to establish a secure connection 
   to one of your experiment nodes via its serial line. 
   When you click the link, tiptunnel will transparently 
   provide a secure connection and launch telnet so you 
   can use that connection.

4. If you move the tiptunnel binary, you may need to reassociate the
   MIME type with the binary in the new location.


